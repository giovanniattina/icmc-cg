#ifndef __VERTEX_H__
#define __VERTEX_H__




typedef struct {

    float matrix[9]

}vertex;


